const express = require("express");
const appRouter = express.Router();

const authenticationRouter = require("./authentication");
const menuRouter=require('./menu')
const dashboardRouter=require('./dashboard');
const adminDashboardRouter=require('./adminDashboard')

appRouter.use(authenticationRouter);
// appRouter.use(menuRouter);
appRouter.use(dashboardRouter);
// appRouter.use(adminDashboardRouter);

module.exports = appRouter;
