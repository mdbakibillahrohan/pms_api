

const { 
    getData 
} = require('../../../util/dao');
const { 
    dbConfig3 
} = require('../../../util/settings');

const getBiddingListsReportServices = async (payload)=>{
    const data = await getTenderDetails(payload);
    //const count=await getCount(payload);
    //console.log(data.length)
    if(data.length){
        return {data: JSON.parse(data[0].data)};
    }else{
        return {data:[]};;
    }
}

const getTenderDetails = async (payload)=>{
    const {TenderNo}=payload;

    const query = `select(SELECT B.TenderNo,A.OpenDate,A.CloseDate,
        (
            case when DATEDIFF(second,A.OpenDate,GETDATE())>1 and DATEDIFF(second,DATEADD(MINUTE,ISNULL((SELECT SUM(K.Minutes) FROM TimerLogs K WHERE K.TenderBidId=A.TenderBidId),0),A.CloseDate),GETDATE())<1 then 1
            when DATEDIFF(second,A.OpenDate,GETDATE())<1 and DATEDIFF(second,DATEADD(MINUTE,ISNULL((SELECT SUM(K.Minutes) FROM TimerLogs K WHERE K.TenderBidId=A.TenderBidId),0),A.CloseDate),GETDATE())<1 then 2
            else 3
            end
        ) as TimeStatus,
        (
            case when DATEDIFF(second,A.OpenDate,GETDATE())>1 and DATEDIFF(second,DATEADD(MINUTE,ISNULL((SELECT SUM(K.Minutes) FROM TimerLogs K WHERE K.TenderBidId=A.TenderBidId),0),A.CloseDate),GETDATE())<1 then 
            DATEDIFF(second,GETDATE(),DATEADD(MINUTE,ISNULL((SELECT SUM(K.Minutes) FROM TimerLogs K WHERE K.TenderBidId=A.TenderBidId),0),A.CloseDate))
            when DATEDIFF(second,A.OpenDate,GETDATE())<1 and DATEDIFF(second,
            DATEADD(MINUTE,ISNULL((SELECT SUM(K.Minutes) FROM TimerLogs K WHERE K.TenderBidId=A.TenderBidId),0),A.CloseDate),GETDATE())<1 then DATEDIFF(second,GETDATE(),A.OpenDate)
            else '000'
            end
        ) as Times,
        (
        select  
            A.ItemId,A.ItemName+' '+A.ItemRemarks As ItemName,
			(case when E.GradeName is not null then E.GradeName
			else 'N/A' end) as GradeName
			,A.UnitOfMeasurement,A.ItemQuantity,A.ItemRate as LastPrice,A.LastBidDate,C.TenderUserId,D.CompanyName,D.CompanyPhone,D.CompanyEmail,Max(C.BidPrice) as BidPrice ,
            (select Max(BB.BidPrice) from BiddingDetails BB where BB.ItemId=C.ItemId) as TopPrice,
            (
				select BB.CompanyName from TenderUsers BB inner join BiddingDetails TT on BB.TenderUserId=TT.TenderUserId 
				where  TT.ItemId=C.ItemId  and  TT.BidPrice=ISNULL((select Max(BB.BidPrice) from BiddingDetails BB where BB.ItemId=C.ItemId),0)
            order by BB.CreatedAt asc
            for json path 
            ) as Winner
            from TenderItems A
            inner join Tender B on A.TenderId=B.TenderId
            inner join BiddingDetails C on A.ItemId=C.ItemId
            left join TenderGrade  E on A.TenderGradeId=E.TenderGradeId
            inner join TenderUsers D on C.TenderUserId=D.TenderUserId
            where B.TenderNo='${TenderNo}' 
            group by A.ItemId, C.TenderUserId,C.ItemId,A.ItemName,A.ItemRemarks,A.ItemId,E.GradeName,A.ItemRate,A.LastBidDate,A.UnitOfMeasurement,A.ItemQuantity,C.TenderUserId,D.CompanyName,D.CompanyPhone,D.CompanyEmail for json path
        ) as lists
        from TenderBidLists A
        inner join Tender B on A.TenderId=B.TenderId
        where B.TenderNo='${TenderNo}' for json path) as data`;
    const data = await getData(dbConfig3, query);
    return data; 
}

module.exports = getBiddingListsReportServices;