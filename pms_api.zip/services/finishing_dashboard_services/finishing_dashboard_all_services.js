
const { getData } = require('../../util/dao');
const { dbConfig } = require('../../util/settings');

const finishingDashboardAllServices = async (payload)=>{
    //const data = await getAchievementData(payload);
    return "success";
}

const finishingDashboardAllData = async(payload)=>{
    
}



module.exports = finishingDashboardAllServices;