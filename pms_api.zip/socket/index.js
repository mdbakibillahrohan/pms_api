
module.exports = (io)=>{
    io.on("new-user", (data)=>{
        
    })
}